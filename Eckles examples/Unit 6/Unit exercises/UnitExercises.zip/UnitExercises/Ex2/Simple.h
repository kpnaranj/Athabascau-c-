
#ifndef SIMPLE_H
#define SIMPLE_H

class Simple {
	public:
	Simple();
	~Simple();	
};

#endif