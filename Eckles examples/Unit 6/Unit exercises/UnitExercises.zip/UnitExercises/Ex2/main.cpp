/*
1.Write a simple class called Simple with a constructor that prints something to 
tell you that it�s been called. In main( ) make an object of your class.
2.Add a destructor to Exercise 1 that prints out a message to tell you that it�s 
been called.
*/
#include "Simple.h"
#include <iostream>
using namespace std;

int main(){
	Simple s;	
}
