/*
Modify the Handle.h, Handle.cpp, and UseHandle.cpp files at the end of Chapter 5 
to use constructors and destructors.
*/
#include "Handle.h"

int main() {
	Handle u;
	u.read();
	u.change(1);	
} ///:~