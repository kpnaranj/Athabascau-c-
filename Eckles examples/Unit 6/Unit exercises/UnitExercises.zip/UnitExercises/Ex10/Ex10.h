#ifndef EX10_H
#define EX10_H

class Ex10{
	private:
	int x;
	//public:
	//Ex10(int i);	
};
#endif