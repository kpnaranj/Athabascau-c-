#include "Ex10.h"
#include <iostream>
using namespace std;

Ex10::Ex10(){
	x = 0;	
	cout<<"Value initialized"<<endl;
}

/*Ex10::Ex10(int i){} // invalid argument*/



