#include "Ex10.h"
#include <iostream>

int main(){
	Ex10 s;	
}
